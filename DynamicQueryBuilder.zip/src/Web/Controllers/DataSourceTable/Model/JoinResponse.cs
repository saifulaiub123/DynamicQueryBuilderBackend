﻿using Involys.Poc.Api.Controllers.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Involys.Poc.Api.Controllers.DataSourceTable.Model
{
    public class JoinResponse : BaseEntity
    {
       
        public string Designation { get; set; }
    }
}
