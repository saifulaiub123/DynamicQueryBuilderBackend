﻿namespace Involys.Poc.Api
{
    public static class Constants
    {

        public const string CommandeNotFound = "Commande not found";
        public const int NoValue = -1;

        public const string ValueMustBeUnique = "The value must be unique";
    }
}
 