﻿using System.Collections.Generic;

namespace Involys.Poc.Api.Common.Security
{
    public class Clazz
    {
        public string Name{ get; set; }
        public List<Field> Fields { get; set; }
    }
}
