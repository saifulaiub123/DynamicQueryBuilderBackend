﻿namespace Involys.Poc.Api.Common.Security
{
    public class Field
    {
        public string Name { get; set; }
    }
}
